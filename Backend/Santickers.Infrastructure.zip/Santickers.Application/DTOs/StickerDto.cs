using System;
using System.Collections.Generic;
using System.Text;

namespace Santickers.Application.DTOs
{
	public class StickerDto
	{
		public int Id { get; set; }

		public string Name { get; set; } = string.Empty;

		public string? Description { get; set; }

		public decimal Price { get; set; }

		public string? ImageUrl { get; set; }

		public int CategoryId { get; set; }

		public string CategoryName { get; set; } = string.Empty;
	}
}